classify_image.py  - This script is used to run inference on an image passed as an argument in the terminal with the '--image flag'

classify_webcam.py - This script when run opens your wecam. Hold an indian currency note from the classes trained (10, 20(old only), 100, 200) and press space when the webcam opens. It will then show the output of the classification in the terminal.
